<html>
<head>
    <?php
    require_once('../base.php');
    ?>
<link rel="stylesheet" type="text/css" href="../style.css">
<link rel="stylesheet" type="text/css" href="login.css">
<script src="jquery-3.3.1.min"></script>
</head>
<body>
<div id="content2">
	  <div id="loginblock">
	<img src="../title.png" id="titlelogin" class="center">
        <input type="text" class="inputs" placeholder="Username" name="username">
        <input type="password" class="inputs" placeholder="Password" name="pass">
        <button onclick="" type="button" id="loginbutton"><span>Log in</span></button>
	</div>
</div>



<?php

  require_once(__ROOT__ .'/connect.php');



?>

<script type="text/javascript">

	

</script>
</body>
</html> 