<?php
define('__ROOT__', dirname(__FILE__));
